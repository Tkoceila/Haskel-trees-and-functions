{-----------------------------------NOTICE D'UTILISATION-------------------------------------------------}


--exemple d'utilisation :

--ajouter 15 Vide
--ajouter 18 (Noeud Vide 15 Vide) 
--ajouter 10 (Noeud Vide 15 (Noeud Vide 18 Vide)) 
--recherche 18 (Noeud 15 (Noeud 10 Vide Vide) (Noeud 18 Vide Vide))

import Data.List 
--type Noeud = Abr 
data Abr a = Vide | Noeud (Abr Int) Int (Abr Int) deriving (Show, Eq, Ord)

increment :: Int -> Abr Int -> Abr Int
--cas d'arbre vide ou feuille
increment v Vide = Vide---(Noeud Vide v Vide)     
--cas d'arbre non vide 
increment v (Noeud g cle d) = Noeud (increment v g) (cle+v) (increment v d)                
            



ajouter :: Int -> Abr Int -> Abr Int  
--cas d'un arbre vide-- f est un int elle represente la valeur associée à un noeud--
ajouter f Vide = (Noeud Vide f Vide) 
--cas d'un arbre (noeud) non vide--- 
--g et d representent respectivement le fils gauche et le fils droit--
ajouter num (Noeud g cle d) 
               | cle == num = Noeud g cle d
               | cle < num  = Noeud g cle (ajouter num d )  
               | cle > num  = Noeud (ajouter num g) cle d


recherche :: Int -> Abr Int -> Abr Int
recherche num Vide = Vide
recherche num (Noeud g cle d) 
               | num == cle   = Noeud g cle d        -- condition d'arret 
               | num > cle    = recherche num d      -- recursion dans le sous arbre droit
               | num < cle    = recherche num g      -- recursion dans le sous arbre gauche 
