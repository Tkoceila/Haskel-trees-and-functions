-- Definition d'un arbre binaire
data TreeMap b = Empty | Node Int b (TreeMap b) (TreeMap b)

-- Types des fonctions :
tmLookup :: TreeMap Int -> b -> Maybe b		-- rechercher la valeur associee a une cle passee en parametre
tmInsert :: TreeMap b -> Int -> b -> TreeMap b	-- ajouter une entree dans la table
tmRemove :: TreeMap b -> Int -> TreeMap b	-- enlever une entree dont la clef est passee en parametre

-- Code
tmLookup (Node k v left right) k'
			| k' == k   = Just v
			| k' < k    = tmLookup (left) k'	-- recursion dans le sous arbre gauche
			| otherwise = tmLookup (right) k'	-- recursion dans le sous arbre droit

tmInsert Empty k' v' = Node k' v' Empty Empty			-- Si arbre (ou sous arbre) vide
tmInsert (Node k v l r) k' v'
			| k' == k   = Node k' v' l r
			| k'<k      = Node k v (tmInsert l k' v')r
			| otherwise = Node k v l (tmInsert r k' v')

tmMerge :: TreeMap b -> TreeMap b -> TreeMap b
tmMerge Empty t = t
tmMerge (Node k v l r) t = Node k v l (tmMerge r t)

tmRemove Empty _ = Empty
tmRemove (Node k v l r) k'
			| k'<k = Node k v (tmRemove l k') r
			| k'>k = Node k v l (tmRemove r k')
			| otherwise = tmMerge l r
