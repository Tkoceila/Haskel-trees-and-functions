import Data.List 
--type Noeud = Abr 
data Abr a = Vide | Noeud (Abr Int) Int (Abr Int) deriving (Show, Eq, Ord)



---fonction d'ajout----------------------------------------------------------------------------
ajouter :: Int -> Abr Int -> Abr Int  
--cas d'un arbre vide-- f est un int elle represente la valeur associée à un noeud--
ajouter f Vide = (Noeud Vide f Vide) 
--cas d'un arbre (noeud) non vide--- 
--g et d representent respectivement le fils gauche et le fils droit--
ajouter num (Noeud g cle d) 
               | cle == num = Noeud g cle d
               | cle < num  = Noeud g cle (ajouter num d )  
               | cle > num  = Noeud (ajouter num g) cle d


---fonction de recherche-------------------------------------------------------------------------

-- rechercher la valeur associee a une cle passee en parametre
recherche :: Int -> Abr Int -> Abr a
--cas d'arbre vide ou feuille 
recherche num Vide = Vide
--cas d'arbre non vide 
recherche num (Noeud g cle d) 
               | num == cle   = Noeud g cle d        -- condition d'arret récursion
               | num > cle    = recherche num d      -- recursion dans le sous arbre droit
               | num < cle    = recherche num g      -- recursion dans le sous arbre gauche 

---incrémentation de toutes les clés par la valeur de "v" -----------

increment :: Int -> Abr Int -> Abr Int
--cas d'arbre vide ou feuille (condition d'arret récursion)
increment v Vide = Vide---(Noeud Vide v Vide)     
--cas d'arbre non vide 
increment v (Noeud g cle d) = Noeud (increment v g) (cle+v) (increment v d)    
            

--------------Multiplication par 2---------------------------------------------

multiplie :: Abr Int -> Abr Int
--cas d'arbre vide  ou feuille (condition d'arret récursion)
multiplie Vide = Vide 
--cas d'arbre non vide 
multiplie (Noeud g cle d) = Noeud (multiplie g) (cle*2) (multiplie d)


------------Fonction d'inversion des signes de chaque clé-----------------------

inversion :: Abr Int -> Abr Int
--cas d'arbre vide  ou feuille (condition d'arret récursion)
inversion Vide = Vide 
--cas d'arbre non vide 
inversion (Noeud g cle d) = Noeud (inversion d) (cle*(-1)) (inversion g)


----------Fusion de deux arbre --------------------------------------------------

fusion :: Abr Int -> Abr Int -> Abr Int
fusion Vide Vide = Vide
fusion Vide (Noeud g cle d) = (Noeud g cle d)
fusion (Noeud g cle d) Vide = (Noeud g cle d)
fusion (Noeud g cle d) (Noeud g2 cle2 d2) = ajouter cle2 (fusion g2(fusion d2(Noeud g cle d)))



--------Fonction de suppréssion --------------------------------------------------

supprime :: Abr Int -> Int -> Abr Int
supprime Vide _ = Vide
supprime (Noeud t1 v t2) x  
        | x == v = subprime (Noeud t1 v t2)  --Attention ici on fait appel à la sous routine subprime qui sera axplicitée plus bas 
        | x  < v = Noeud (supprime t1 x) v t2
        | x  > v = Noeud t1 v (supprime t2 x)

-- subprime : sous fonction de suppression (utilisée dans le sous arbre) en cas de 
-- suppression d'un noeud ayant un fils gauche et droit non vides 
subprime :: Abr Int -> Abr Int
subprime (Noeud Vide v Vide) = Vide
subprime (Noeud Vide v t2) = t2
subprime (Noeud t1 v Vide) = t1
subprime (Noeud t1 v t2) = (Noeud t1 v2 t3) 
                where 
                v2 = plusAgaucheFdroit t2     --sous routine qui va chercher le bon remplaçant (v2) au nud supprimé (v)
                t3 = supprime t2 v2           --sous arbre droit sans la valeur v2

-- plusAgaucheFdroit : cette sous fonction retourne le plus à gauche du fils droit -ie- plus petite valeur 
-- du fils droit 
plusAgaucheFdroit :: Abr Int -> Int
plusAgaucheFdroit (Noeud Vide v _) = v
plusAgaucheFdroit (Noeud t1 _ _) = plusAgaucheFdroit t1



{--------------------------------------NOTICE D'UTILISATION-------------------------------------------------------}

------Expliquations--------------------------------

--Choix de typage--:
--Tout d'abord la forme de l'arbre est la suivante (fils gauche) clé (fils droit)
--Le type de la clé est un int au lieu d'un type plus générique, ce choix est volontaire et a pour but de 
--faciliter les fonction arithmétiques sur les clés



--Fonction de suppression--:
--le corps de la fonction principale prend en compte, de manière exhaustive, tous les cas d'arbres qu'on pourrait 
--Rencontrer une fois que le noeud à supprimer est identifié alors la première sous routine (subprime)
--s'occupe de le supprimer en remplaçant sa valeur par la valeur min du 
--fils droit retournée par la deuxième sous routine (plusAgaucheFdroit).

--Utilité de cette dernière sous routine (plusAgaucheFdroit):
--Cas ou le Noeud a supprimer a un fils gauche et droit non vides alors ici deux choix se posent à nous :
--Remplacer ce noeud par le plus a gauche de ses fils droits oubien par le plus a droite de ses fils gauche 
--Pourquoi ?!
--car c'est la valeur la plus à meme de reprendre la place du noeud supprimé et cela nous permet de reprendre les memes fils de part et d'autre 
----Nous avons choisi le min du fils droit 




--exemple d'utilisation de chaque fonction:------------

--ajouter 15 Vide
--ajouter 18 (Noeud Vide 15 Vide) 
--ajouter 10 (Noeud Vide 15 (Noeud Vide 18 Vide))

--recherche 18 (Noeud (Noeud Vide 10 Vide) 15 (Noeud Vide 18 Vide))

--increment 1 (Noeud (Noeud Vide 10 Vide) 15 (Noeud Vide 18 Vide))

--fusion (Noeud Vide 5 (Noeud Vide 7 (Noeud Vide 8 (Noeud Vide 10 Vide)))) (Noeud (Noeud Vide 3 Vide) 6 Vide)

--supprime (Noeud (Noeud Vide 10 Vide) 15 (Noeud Vide 18 Vide)) 15

--multiplie (Noeud (Noeud Vide 10 Vide) 15 (Noeud Vide 18 Vide))

--inversion (Noeud (Noeud Vide 10 Vide) 15 (Noeud Vide 18 Vide))

-------------------------------------------------------------------------------------------------------------------------

 


