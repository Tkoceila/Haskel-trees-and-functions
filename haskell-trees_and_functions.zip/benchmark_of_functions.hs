

-----PROJET REPRIS : 324
import           Control.DeepSeq
import           System.CPUTime

import System.Random     
import Data.List            

--type Noeud = ARN 
data ARN a =  Vide 
             |Noeud Color(ARN a) Int (ARN a) deriving (Show, Eq, Ord)

data Color = Rouge
            |Noir
            |PasDeCouleur  deriving(Show, Eq, Ord)

--tree2 =Noeud Rouge (Noeud Rouge (Noeud Noir Vide 11 Vide) 15 (Noeud Rouge Vide 22 Vide)) 25 (Noeud Noir Vide 60 Vide) 

---------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------Fonction de Recherche-------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------

                  ---La fonction recherche prend en paramétre l'entier à rechercher dans l'arbre ARN ---
                  ---et retourne vrai ainsi que la couleur du noeud (rouge ou noir) s'il existe      ---
                  ---sinon faux s'il n'existe donc la couleur est PasDeCouleur                       ---

recherche :: Int ->ARN Int -> (Bool,Color)  
recherche num Vide =(False,PasDeCouleur)
--cas d'arbre non vide 
recherche num (Noeud c g cle d) 
               | num == cle   = (True,c)             -- condition d'arret récursion
               | num > cle    = recherche num d      -- recursion dans le sous arbre droit
               | num < cle    = recherche num g      -- recursion dans le sous arbre gauche 

----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------Fonction de Rotation---------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------
 
                 ---la fonction rotation prend en paramétre un arbre et le transforme en arbre
                 ---équilibré, on fait appelle à cette fonction pour ne pas violer les régles
                 ---suivantes:
                 ---             **La racine et les feuilles de l'arbre sont noirs
                 ---             **Les ﬁls d’un noeud rouge sont noirs 
                 ---             **Le nombre de noeuds noirs croisés depuis la
                 ---                  racine à une feuille est constant         

rotationARN :: Color -> ARN Int -> Int -> ARN Int-> ARN Int
rotationARN Noir (Noeud Rouge (Noeud Rouge a x b) y c) z d = Noeud Rouge (Noeud Noir a x b) y (Noeud Noir c z d)
rotationARN Noir (Noeud Rouge a x (Noeud Rouge b y c)) z d = Noeud Rouge (Noeud Noir a x b) y (Noeud Noir c z d)
rotationARN Noir a x (Noeud Rouge b y (Noeud Rouge c z d)) = Noeud Rouge (Noeud Noir a x b) y (Noeud Noir c z d)
rotationARN Noir a x (Noeud Rouge (Noeud Rouge b y c) z d) = Noeud Rouge (Noeud Noir a x b) y (Noeud Noir c z d)
rotationARN couleur a x b = Noeud couleur a x b   

----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------Fonction blacken-------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------

                 ---La fonction blacken  change la couleur du nœud en noir quelle
                 --- que soit la couleur du nœud

blacken :: ARN Int -> ARN Int
blacken Vide = error "Arbre Vide"
blacken (Noeud _ a x b) = Noeud Noir a x b

----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------Fonction d'insertion---------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------

               ---on ajoute toujours un noeud rouge pour ne pas affecter la hauteur 
               ---et on utilise la fonction de rotation pour équilibrer l'arbre

ajouter :: Int -> ARN Int -> ARN Int                    
ajouter num tree = blacken (ajout tree) 
 where ajout Vide = Noeud Rouge Vide num Vide
       ajout tree @(Noeud couleur g cle d) | num < cle = rotationARN couleur (ajout g) cle d
                                           | num > cle = rotationARN couleur g cle (ajout d)
                                           | otherwise = tree

----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------Fonction redden-------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------

                 ---La fonction redden  change la couleur du nœud en rouge quelle
                 --- que soit la couleur du nœud

redden :: ARN Int -> ARN Int
redden Vide = error "Arbre Vide"
redden (Noeud _ a x b) = Noeud Rouge a x b

----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------Fonction isBB----------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------

isBB :: ARN Int-> Bool
isBB _ = False

----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------Fonction colNoir-------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------

colNoir :: Color -> Color
colNoir Rouge = Noir

----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------Fonction colRouge------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------

colRouge :: Color -> Color
colRouge Noir = Rouge

----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------Fonction colNoir'------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------

colNoir' :: ARN Int -> ARN Int
colNoir' (Noeud c l x r) = Noeud (colNoir c) l x r

----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------Fonction colRouge'-----------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------

colRouge' :: ARN Int -> ARN Int
colRouge' (Noeud c l x r) = Noeud (colRouge c) l x r 

----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------Fonction proc--------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------

                ---La fonction proc  déplace noirs des enfants aux parents
                --- ou les élimine complètement si possible

proc :: Color -> ARN Int -> Int -> ARN Int -> ARN Int
proc color l x r
 | isBB(l) || isBB(r) = rotationARN (colNoir color) (colRouge' l) x (colRouge' r)
 | otherwise          = rotationARN color l x r

----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------Fonction maxARN--------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------

maxARN :: ARN Int -> Int
maxARN Vide = error "Arbre Vide"
maxARN (Noeud _ _ x Vide) = x
maxARN (Noeud _ _ x r) = maxARN r

----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------Fonction de supression-------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------

supprimerARN :: Int -> ARN Int -> ARN Int
supprimerARN x s = blacken(supp s)
 where supp Vide = Vide
       supp s@(Noeud color a y b) | x < y     = proc color (supp a) y b  
                             | x > y     = proc color a y (supp b)
                             | otherwise = eliminer s

-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------Fonction d'elimination--------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------

                   ---si on veut éliminer la racine on la remplace par
                   ---le plus grand des éléments de sous arbre gauche 

eliminer :: ARN Int -> ARN Int
eliminer Vide = Vide
eliminer (Noeud Rouge Vide _ Vide) = Vide
eliminer (Noeud Noir Vide _ Vide) = Vide
eliminer (Noeud Noir Vide _ (Noeud Rouge a x b)) = Noeud Noir a x b
eliminer (Noeud Noir (Noeud Rouge a x b) _ Vide) = Noeud Noir a x b
eliminer (Noeud color l y r) = proc color liste mx r 
 where mx = maxARN l
       liste = eliminerMax l

---------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------Fonction d'eliminationMax---------------------------------------------------
 --------------------------------------------------------------------------------------------------------------------------

eliminerMax :: ARN Int -> ARN Int
eliminerMax Vide = error "Arbre Vide"
eliminerMax s@(Noeud _ _ _ Vide) = eliminer s
eliminerMax s@(Noeud color l x r) = proc color l x (eliminerMax r)

--------------------------------------------------------------------------------------------------------------------------
--------------------------------incrémentation de toutes les clés par la valeur de "v" -----------------------------------
--------------------------------------------------------------------------------------------------------------------------

increment :: Int -> ARN Int -> ARN Int
--cas d'arbre vide ou feuille (condition d'arret récursion)
increment v Vide = Vide---(Noeud Vide v Vide)     
--cas d'arbre non vide 
increment v (Noeud c g cle d) = Noeud c (increment v g) (cle+v) (increment v d)    
            

--------------------------------------------------------------------------------------------------------------------------
----------------------------------------------Multiplication par 2--------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------

multiplie :: ARN Int -> ARN Int
--cas d'arbre vide  ou feuille (condition d'arret récursion)
multiplie Vide = Vide 
--cas d'arbre non vide 
multiplie (Noeud c g cle d) = Noeud c (multiplie g) (cle*2) (multiplie d)

--------------------------------------------------------------------------------------------------------------------------
----------------------------------Fonction d'inversion des signes de chaque clé-------------------------------------------
--------------------------------------------------------------------------------------------------------------------------
inversion :: ARN Int -> ARN Int
--cas d'arbre vide  ou feuille (condition d'arret récursion)
inversion Vide = Vide 
--cas d'arbre non vide 
inversion (Noeud c g cle d) = Noeud c (inversion d) (cle*(-1)) (inversion g)

--------------------------------------------------------------------------------------------------------------------------
---------------------------------------------Fonction rotationDroite------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------

rotationDroite :: ARN Int-> ARN Int
rotationDroite (Noeud Noir (Noeud Rouge t1 x t2) y t3) = Noeud  Rouge (Noeud  Noir t1 x t2) y t3
rotationDroite (Noeud Noir t1 y (Noeud Noir t2 z t3)) = rotationARN Noir t1 y (Noeud Rouge t2 z t3)
rotationDroite (Noeud Noir t1 y (Noeud Rouge (Noeud Noir t2 u t3) z t4@(Noeud Noir l value r))) =
  Noeud Rouge (Noeud Noir t1 y t2) u (rotationARN Noir t3 z (Noeud Rouge l value r))


----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------fusion-----------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------
fusion :: ARN Int-> ARN Int -> ARN Int
fusion Vide tree = tree
fusion tree Vide = tree
fusion tr1@(Noeud Noir _ _ _) (Noeud Rouge t3 y t4) = Noeud Rouge (fusion tr1 t3) y t4
fusion (Noeud Rouge t1 x t2) t3@(Noeud Noir _ _ _) = Noeud Rouge t1 x (fusion t2 t3)
fusion (Noeud Rouge t1 x t2) (Noeud Rouge t3 y t4)  =
  let s = fusion t2 t3
  in case s of
       (Noeud Rouge s1 z s2) -> (Noeud Rouge (Noeud Rouge t1 x s1) z (Noeud Rouge s2 y t4))
       (Noeud Noir  _ _ _)  -> (Noeud Rouge t1 x (Noeud Rouge s y t4))
fusion (Noeud Noir t1 x t2) (Noeud Noir t3 y t4)  =
  let s = fusion t2 t3
  in case s of
       (Noeud Rouge s1 z s2) -> (Noeud Rouge (Noeud Noir t1 x s1) z (Noeud Noir s2 y t4))
       (Noeud Noir s1 z s2) -> rotationDroite (Noeud Noir t1 x (Noeud Noir s y t4))


---------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------          Phase 3        ---------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------

--PROJET REPRIS : 324



---------------------------------------------------------------------------------------------------------------------------
------------------------------------------------     Fonction Prendre    --------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------
--Question 2 
--qui permet de prendre n premiers éléments d'une liste

prendre :: Integer -> [a] -> [a]
prendre 0 _ = []
prendre n (x:l) = x:(prendre (n-1) l) 

---------------------------------------------------------------------------------------------------------------------------
------------------------------------------------     Fonction Prendre    --------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------

--                                                              NewList, prend en paramètre une cide "n" et un int "m"
--                                                              qui permet de génerer une liste aléatoir de m éléments
--                                                              compris entre 0 et m^2
newList:: Int -> Integer -> [Integer]
newList n m = prendre m $ randomRs (0,m*m) (mkStdGen n) --- :: --[Integer]


--Question 3

--                                                              toARN qui insère les éléments de la liste dans l’ARN.

toARN:: [Integer]-> ARN Int
toARN []    = Vide
toARN (x:l) = ajouter (fromIntegral x) (toARN l)


--question 4

--                                                             qui insère dans l’arbre vide n noeuds aléatoires tirés
--                                                             dans[0; n2](avecnen paramètre)
randomARN :: Int -> ARN Int 
randomARN n = toARN (newList (n*5) (toInteger n))


--Question 6

testARNrouge :: ARN Int -> Bool
testARNrouge Vide = True
testARNrouge (Noeud Rouge (Noeud Rouge g cle d) cle2 d2) = False
testARNrouge (Noeud Rouge  g cle (Noeud Rouge g2 cle2 d2)) = False
testARNrouge (Noeud c1 g cle d) = (testARNrouge g) && (testARNrouge d) 

--                                                              nbnoirs qui compte le nobre de noirs de la branche 
--                                                              la plus à gauche de l'arbre 
nbnoirs :: ARN Int -> Int
nbnoirs Vide = 0
nbnoirs (Noeud Noir g cle d) = ((nbnoirs g)+1)
nbnoirs (Noeud Rouge g cle d) = (nbnoirs g)

--                                                              testnoir test si il y a le meme nbre de noeuds noirs
--                                                              sur toutes les branches


testnoirs :: Int -> ARN Int -> Bool
testnoirs n Vide = if (n==0) then True else False  
testnoirs n (Noeud Noir g cle d) = (testnoirs (n-1) g) && (testnoirs (n-1) d)
testnoirs n (Noeud Rouge g cle d) = (testnoirs (n) g) && (testnoirs (n) d)

--                                                              qui renvoie true si l'arbre est un arn false autrement


testARN :: ARN Int -> Bool
testARN (Noeud c g cle d) = (testARNrouge (Noeud c g cle d)) && (testnoirs (nbnoirs (Noeud c g cle d)) (Noeud c g cle d)) 









--Question 5

{-main = do
putStrLn ("Pour quelle taille d'arbre voulez-vous faire un test ?")
n     <- getLine
start <- getCPUTime
end   <- seq (randomARN (read n)) getCPUTime
putStrLn ("temps de création Arn "++ show(end-start)) --}




--------------------------------------------------Fonction utillitaires ---------------------------------------------
--------------tailleARn--
--fonction de récuperation de la taille des ARN ie le nombre de noeuds

tailleARN :: ARN Int -> Int
tailleARN Vide = 0
tailleARN (Noeud c g cle d) = tailleARN(g)+tailleARN(d)+1


----Redefinition de la fontion toARN------------------------------------

toARN2:: [Integer]-> ARN Int
toARN2 []    = Vide
toARN2 (x:l) = supprimerARN (fromIntegral x) (ajouter (fromIntegral x) (toARN2 l))


-- on pourra rajouter la fonction "prendre" a cette section 

--------------------------------------------Fin de fonctions utilitaires ----------------------------------------------

--Question 7 et 8


----                                                              test qui genère un benchmarck sur les test 
--                                                                prend un int en entree qui est le nombre de créations
test :: Int -> IO ()
test t = if (t==0 || t<0) then putStrLn ("Fin du test") 
else  do {
putStrLn ("----------début test pour "++show(t)++" -----------")
;start   <- getCPUTime
;end     <- seq (randomARN t)  getCPUTime
;putStrLn ("temps de création Arn : "++ show((fromIntegral(end-start)) / 1000000000) ++" millisecondes")
;putStrLn ("taille ARN            : "++ show(tailleARN (randomARN t)))
;putStrLn ("test ARN correct      ? "++show(testARN (randomARN t)))
;test (t-50)}



--Interprétation : Il y a une relation proportionnelle entre le nombre de noeuds de l'arbre et le temps d'xecution


--Question 9
--Premiere interprétation de la question (temps d'execution de chaque fonction intermediaire à la creation d'un arbre aléatoire

test9 :: Int -> IO ()
test9 t =  do
{ putStrLn ("----------début test pour "++show(t)++" -----------")
;start   <- getCPUTime
;end     <- seq (randomARN t)  getCPUTime
----------------------------------
;start2  <- getCPUTime
;end2    <- seq (newList t  (toInteger t)) getCPUTime
----------------------------------
;start4  <- getCPUTime
;end4    <- seq (toARN (newList (t*5) (toInteger t))) getCPUTime

;putStrLn ("temps d'execution fontion newList : "++ show((fromIntegral(end2-start2)) / 1000000000) ++" millisecondes")


;putStrLn ("temps d'execution fonction toARN  : "++ show((fromIntegral(end4-start4)) / 1000000000) ++" millisecondes")


;putStrLn ("temps de création Arn (randomARN) : "++ show((fromIntegral(end-start)) / 1000000000) ++" millisecondes")

}

--Question 9   --BIS

-- temps intermédiair entre la creation, de 2 arn
test2 :: Int -> IO ()
test2 t = if (t==0 || t<0) then putStrLn ("Fin du test") 
else  do{
putStrLn ("----------début test pour "++show(t)++" -----------")
;start1   <- getCPUTime
;end1     <- seq (randomARN t)  getCPUTime
;start2   <- getCPUTime
;putStrLn ("temps intermediaire de création Arn : "++ show(end1-start2) ++" picosecondes")
;end1     <- seq (randomARN t)  getCPUTime
;test2 (t-50)
}


--Définition temps intermédiaire : temps entre deux choses 
--source : http://www.linternaute.fr/dictionnaire/fr/definition/intermediaire/





--Question 10
--On supposant que la moyenne est celle de chaque fonction intermediaire pour la création d'un arn

test10 :: IO ()
test10 = do {
putStrLn ("----------début test pour n=50 -----------")

;putStrLn ("----------pour n = 50 -----------\n")

;randomstart   <- getCPUTime
;randomend     <- seq (randomARN 50)  getCPUTime
----------------------------------
;newliststart  <- getCPUTime
;newlistend    <- seq (newList 50  (toInteger 50)) getCPUTime
----------------------------------
;toarnstart  <- getCPUTime
;toarnend    <- seq (toARN (newList (1524542) (toInteger 50))) getCPUTime

;putStrLn ("temps d'execution fontion newList : "++ show((fromIntegral(newlistend-newliststart)) / 1000000000) ++" millisecondes")


;putStrLn ("temps d'execution fonction toARN  : "++ show((fromIntegral(toarnend-toarnstart)) / 1000000000) ++" millisecondes")


;putStrLn ("temps de création Arn (randomARN) : "++ show((fromIntegral(randomend-randomstart)) / 1000000000) ++" millisecondes")


;putStrLn ("----------pour n = 100 -----------\n")

;randomstart1  <- getCPUTime
;randomend1     <- seq (randomARN 100)  getCPUTime
----------------------------------
;newliststart1  <- getCPUTime
;newlistend1    <- seq (newList 6544  (toInteger 100)) getCPUTime
----------------------------------
;toarnstart1  <- getCPUTime
;toarnend1    <- seq (toARN (newList (56448) (toInteger 100))) getCPUTime

;putStrLn ("Moyennes d'execution fontion newList : "++ show(fromIntegral((newlistend-newliststart)+(newlistend1-newliststart1)) / 2000000000) ++" millisecondes")
 
;putStrLn ("Moyennes d'execution fonction toARN  : "++ show(fromIntegral((toarnend-toarnstart)+(toarnend1-toarnstart1)) / 2000000000) ++" millisecondes")

;putStrLn ("Moyennes de création Arn (randomARN) : "++ show(fromIntegral((randomend-randomstart)+(randomend1-randomstart1)) / 2000000000) ++" millisecondes")


;putStrLn ("----------pour n = 150 -----------\n")

;randomstart2  <- getCPUTime
;randomend2     <- seq (randomARN 150)  getCPUTime
----------------------------------
;newliststart2  <- getCPUTime
;newlistend2    <- seq (newList  68784 (toInteger 150)) getCPUTime
----------------------------------
;toarnstart2  <- getCPUTime
;toarnend2    <- seq (toARN (newList (526544554) (toInteger 150))) getCPUTime

;putStrLn ("Moyennes d'execution fontion newList : "++ show(fromIntegral((newlistend1-newliststart1)+(newlistend2-newliststart2)) / 3000000000) ++" millisecondes")
 
;putStrLn ("Moyennes d'execution fonction toARN  : "++ show(fromIntegral((toarnend1-toarnstart1)+(toarnend2-toarnstart2)) / 3000000000) ++" millisecondes")

;putStrLn ("Moyennes de création Arn (randomARN) : "++ show(fromIntegral((randomend1-randomstart1)+(randomend2-randomstart2)) / 3000000000) ++" millisecondes")

;putStrLn ("----------pour n = 200 -----------\n")

;randomstart3  <- getCPUTime
;randomend3     <- seq (randomARN 200)  getCPUTime
----------------------------------
;newliststart3  <- getCPUTime
;newlistend3    <- seq (newList 6544  (toInteger 200)) getCPUTime
----------------------------------
;toarnstart3  <- getCPUTime
;toarnend3    <- seq (toARN (newList (654984) (toInteger 200))) getCPUTime

;putStrLn ("Moyennes d'execution fontion newList : "++ show(fromIntegral((randomend1-randomstart1)+(newlistend2 - newliststart2)+(newlistend3-newliststart3)) / 2000000000) ++" millisecondes")
 
;putStrLn ("Moyennes d'execution fonction toARN  : "++ show(fromIntegral((toarnend1-toarnstart1)+(toarnend2-toarnstart2)+(toarnend3-toarnstart3)) / 2000000000) ++" millisecondes")

;putStrLn ("Moyennes de création Arn (randomARN) : "++ show(fromIntegral((randomend1-randomstart1)+(randomend2-randomstart2)+(randomend3-randomstart3)) / 2000000000) ++" millisecondes")


;putStrLn ("----------pour n = 250 -----------\n")


;randomstart4  <- getCPUTime
;randomend4     <- seq (randomARN 250)  getCPUTime
----------------------------------
;newliststart4  <- getCPUTime
;newlistend4    <- seq (newList 6845  (toInteger 250)) getCPUTime
----------------------------------
;toarnstart4  <- getCPUTime
;toarnend4    <- seq (toARN (newList (7788) (toInteger 250))) getCPUTime

;putStrLn ("Moyennes d'execution fontion newList : "++ show(fromIntegral((randomend1-randomstart1)+(newlistend2-newliststart2)+(newlistend3-newliststart3)+(newlistend4-newliststart4)) / 4000000000) ++" millisecondes")
 
;putStrLn ("Moyennes d'execution fonction toARN  : "++ show(fromIntegral((toarnend1-toarnstart1)+(toarnend2-toarnstart2)+(toarnend3-toarnstart3)+(toarnend4-toarnstart4)) / 4000000000) ++" millisecondes")

;putStrLn ("Moyennes de création Arn (randomARN) : "++ show(fromIntegral((randomend1-randomstart1)+(randomend2-randomstart2)+(randomend3-randomstart3)+(randomend4-randomstart4)) / 4000000000) ++" millisecondes")


;putStrLn ("----------pour n = 300 -----------\n")

;randomstart5  <- getCPUTime
;randomend5    <- seq (randomARN 300)  getCPUTime
----------------------------------
;newliststart5  <- getCPUTime
;newlistend5   <- seq (newList 6451  (toInteger 300)) getCPUTime
----------------------------------
;toarnstart5  <- getCPUTime
;toarnend5    <- seq (toARN (newList (10588) (toInteger 300))) getCPUTime

;putStrLn ("Moyennes d'execution fontion newList : "++ show(fromIntegral((randomend1-randomstart1)+(newlistend2-newliststart2)+(newlistend3-newliststart3)+(newlistend4-newliststart4)+(newlistend5-newliststart5)) / 5000000000) ++" millisecondes")
 
;putStrLn ("Moyennes d'execution fonction toARN  : "++ show(fromIntegral((toarnend1-toarnstart1)+(toarnend2-toarnstart2)+(toarnend3-toarnstart3)+(toarnend4-toarnstart4)+(toarnend5-toarnstart5)) / 5000000000) ++" millisecondes")

;putStrLn ("Moyennes de création Arn (randomARN) : "++ show(fromIntegral((randomend1-randomstart1)+(randomend2-randomstart2)+(randomend3-randomstart3)+(randomend4-randomstart5)+(randomend4-randomstart5)) / 5000000000) ++" millisecondes") }





------------Question 10  BIS----------------------------------------------------
--en supposant que la moyenne est celle des test sur l'arn ainsin que sa création directe  

test3 :: IO ()
test3 = do {
start1   <- getCPUTime

;putStrLn ("----------début test pour n=50 -----------")
;end1     <- seq (randomARN 50)  getCPUTime
;putStrLn ("temps de création Arn : "++ show((fromIntegral(end1-start1)) / 1000000000) ++" millisecondes")
;putStrLn ("taille ARN            : "++ show(tailleARN (randomARN 50)))
;putStrLn ("test ARN correct      ? "++show(testARN (randomARN 50)))

;putStrLn ("---------- test pour n=100 -----------")
;start2   <- getCPUTime
;end2     <- seq (randomARN 100)  getCPUTime
;putStrLn ("temps de création Arn : "++ show((fromIntegral(end2-start2)) / 1000000000) ++" millisecondes")
;putStrLn ("taille ARN            : "++ show(tailleARN (randomARN 100)))
;putStrLn ("test ARN correct      ? "++show(testARN (randomARN 100)))

;putStrLn ("---------------moyenne 1 : "++show(((fromIntegral(end2-start2))+(fromIntegral(end1-start1)))/2000000000)++" millisecondes-----------\n\n")

;putStrLn ("---------- test pour n=150 -----------")
;start3   <- getCPUTime
;end3     <- seq (randomARN 150)  getCPUTime
;putStrLn ("temps de création Arn : "++ show((fromIntegral(end3-start3)) / 1000000000) ++" millisecondes")
;putStrLn ("taille ARN            : "++ show(tailleARN (randomARN 150)))
;putStrLn ("test ARN correct      ? "++show(testARN (randomARN 150)))

;putStrLn ("---------------moyenne 2 : "++show(((fromIntegral(end2-start2))+(fromIntegral(end1-start1))+(fromIntegral(end3-start3)))/3000000000)++" millisecondes-----------\n\n")

;putStrLn ("---------- test pour n=200 -----------")
;start4   <- getCPUTime
;end4     <- seq (randomARN 200)  getCPUTime
;putStrLn ("temps de création Arn : "++ show((fromIntegral(end4-start4)) / 1000000000) ++" millisecondes")
;putStrLn ("taille ARN            : "++ show(tailleARN (randomARN 200)))
;putStrLn ("test ARN correct      ? "++show(testARN (randomARN 200)))

;putStrLn ("---------------moyenne 3 : "++show(((fromIntegral(end2-start2))+(fromIntegral(end1-start1))+(fromIntegral(end3-start3))+(fromIntegral(end4-start4)))/4000000000)++" millisecondes-----------\n\n")

;putStrLn ("---------- test pour n=250 -----------")
;start5   <- getCPUTime
;end5     <- seq (randomARN 250)  getCPUTime
;putStrLn ("temps de création Arn : "++ show((fromIntegral(end5-start5)) / 1000000000) ++" millisecondes")
;putStrLn ("taille ARN            : "++ show(tailleARN (randomARN 250)))
;putStrLn ("test ARN correct      ? "++show(testARN (randomARN 250))) 

;putStrLn ("---------------moyenne 4 : "++show(((fromIntegral(end2-start2))+(fromIntegral(end1-start1))+(fromIntegral(end3-start3))+(fromIntegral(end4-start4))+(fromIntegral(end5-start5)))/5000000000)++" millisecondes-----------\n\n")

;putStrLn ("---------- test pour n=300 -----------")
;start5   <- getCPUTime
;end5     <- seq (randomARN 300)  getCPUTime
;putStrLn ("temps de création Arn : "++ show((fromIntegral(end5-start5)) / 1000000000) ++" millisecondes")
;putStrLn ("taille ARN            : "++ show(tailleARN (randomARN 300)))
;putStrLn ("test ARN correct      ? "++show(testARN (randomARN 300))) 

;putStrLn ("---------------moyenne 5 : "++show(((fromIntegral(end2-start2))+(fromIntegral(end1-start1))+(fromIntegral(end3-start3))+(fromIntegral(end4-start4))+(fromIntegral(end5-start5)))/6000000000)++" millisecondes-----------\n\n")

;putStrLn ("---------- test pour n=350 -----------")
;start5   <- getCPUTime
;end5     <- seq (randomARN 350)  getCPUTime
;putStrLn ("temps de création Arn : "++ show((fromIntegral(end5-start5)) / 1000000000) ++" millisecondes")
;putStrLn ("taille ARN            : "++ show(tailleARN (randomARN 350)))
;putStrLn ("test ARN correct      ? "++show(testARN (randomARN 350))) 

;putStrLn ("---------------moyenne 6 : "++show(((fromIntegral(end2-start2))+(fromIntegral(end1-start1))+(fromIntegral(end3-start3))+(fromIntegral(end4-start4))+(fromIntegral(end5-start5)))/7000000000)++" millisecondes-----------\n\n") 

;putStrLn ("---------- test pour n=400 -----------")
;start5   <- getCPUTime
;end5     <- seq (randomARN 400)  getCPUTime
;putStrLn ("temps de création Arn : "++ show((fromIntegral(end5-start5)) / 1000000000) ++" millisecondes")
;putStrLn ("taille ARN            : "++ show(tailleARN (randomARN 400)))
;putStrLn ("test ARN correct      ? "++show(testARN (randomARN 400))) 

;putStrLn ("---------------moyenne 7 : "++show(((fromIntegral(end2-start2))+(fromIntegral(end1-start1))+(fromIntegral(end3-start3))+(fromIntegral(end4-start4))+(fromIntegral(end5-start5)))/8000000000)++" millisecondes-----------\n\n")

;putStrLn ("---------- test pour n=450 -----------")
;start5   <- getCPUTime
;end5     <- seq (randomARN 450)  getCPUTime
;putStrLn ("temps de création Arn : "++ show((fromIntegral(end5-start5)) / 1000000000) ++" millisecondes")
;putStrLn ("taille ARN            : "++ show(tailleARN (randomARN 450)))  
;putStrLn ("test ARN correct      ? "++show(testARN (randomARN 450))) 

;putStrLn ("---------------moyenne 8 : "++show(((fromIntegral(end2-start2))+(fromIntegral(end1-start1))+(fromIntegral(end3-start3))+(fromIntegral(end4-start4))+(fromIntegral(end5-start5)))/9000000000)++" millisecondes-----------\n\n")  

;putStrLn ("---------- test pour n=500 -----------")
;start5   <- getCPUTime
;end5     <- seq (randomARN 500)  getCPUTime
;putStrLn ("temps de création Arn : "++ show((fromIntegral(end5-start5)) / 1000000000) ++" millisecondes")
;putStrLn ("taille ARN            : "++ show(tailleARN (randomARN 500)))
;putStrLn ("test ARN correct      ? "++show(testARN (randomARN 500))) 

;putStrLn ("---------------moyenne 9 : "++show(((fromIntegral(end2-start2))+(fromIntegral(end1-start1))+(fromIntegral(end3-start3))+(fromIntegral(end4-start4))+(fromIntegral(end5-start5)))/10000000000)++" millisecondes-----------\n\n")}






