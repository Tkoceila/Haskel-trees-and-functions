    



            
--1
--Empty si il est vide, Tree Int Tree = filsGauche, valeur, filsDroit
--Type couleur--------------------------------------------------
data Color = R | B deriving (Eq, Show)
--Type d'arbre rouge et noire-----------------------------------
data Tree = Empty | Noeud Color Tree Int Tree deriving (Eq, Show)
--Type arbre binaire de recherche ------------------------------
data ABR = E | Node ABR Int ABR deriving (Eq, Show)


--2
------------------------------------------ la fonction cherche le nombre int dans l'abre-------------------
                                                -- elle renvoie True si il existe, False sinon
search :: Int -> Tree -> Bool
search num Empty    = False
search num (Noeud _ ls cle rs)
      | num < cle   = search num ls
      | num > cle   = search num rs
      | num == cle  = True
  

--4
--------------------------------------------Fonction de suppréssion---------------------------------------- 
                                               --prend en paramètre un Arbre de type tree et un int 
                                               --et retourne un arbre de type tree sans le noeud supprimmé et en respectant 
                                               --les conditions d'un ARN pour plus d'explications regarder la section explication 
                                               --en fin de document.



supprime :: Tree -> Int -> Tree                --la sous routine "supprime" nous retourne un arbre qui commence du
                                               --noeud à supprimer et l'quilibre 
supprime Empty _ = Empty
supprime (Noeud c t1 v t2) x  
        | x == v = subprime (Noeud c t1 v t2)  --Attention ici on fait appel à la sous routine subprime qui sera axplicitée plus bas 
        | x  < v = supprime t1 x               --remarquez qu'on ne garde pas les éléments de l'arbre actuel ici 
        | x  > v = supprime t2 x               --et ici justement pour ne retourner que le sous arbre duquel on a supprimé 
                                               -- subprime : sous fonction de suppression (utilisée dans le sous arbre) en cas de 
                                               -- matching du noeud à supprimer.
subprime :: Tree -> Tree 
subprime (Noeud c Empty v Empty) = Empty
subprime (Noeud c Empty v t2) = t2
subprime (Noeud c t1 v Empty) = t1
subprime (Noeud c t1 v t2) = inserer v2 (fusion t1 t3 )--(Noeud c t1 v2 t3) 
                where 
                v2 = plusAgaucheFdroit t2      --sous routine qui va chercher le bon remplaçant (v2) au nud supprimé (v)
                t3 = supprime t2 v2            --sous arbre droit sans la valeur v2
           


plusAgaucheFdroit :: Tree -> Int                            -- plusAgaucheFdroit : cette sous fonction retourne le plus à gauche du fils droit 
                                                            ---ie- plus petite valeur du fils droit                          
plusAgaucheFdroit (Noeud _ Empty v _) = v
plusAgaucheFdroit (Noeud _ t1 _ _)    = plusAgaucheFdroit t1



suppr :: Tree -> Int -> Tree                               --sous routine qui retourne l'arbre en supprimant le noeud à supprimer et ses
                                                           --fils 
suppr (Noeud c t1 v t2) x  
        | x == v = Empty
        | x  < v = Noeud c (suppr t1 x) v t2
        | x  > v = Noeud c t1 v (suppr t2 x)

                                                        -- Après ces innombrebles sous fonctions voici ENFIN ! 
                                                        -- la fonction de suppression qui ne
                                                        -- fait que faire appel à ses sous fonctions


delete :: Tree -> Int -> Tree
delete Empty _ = Empty
delete arn x   = fusion (supprime arn x) ( suppr arn x) 



--3
----------------------------Fonction d'insertion------------------------------------------

                                                       -- la fonction insert l'element int dans l'AVG
                                                       -- si cet élément existe déja, elle renvoie le même arbre
inserer :: Int -> Tree -> Tree
inserer x s =  makeBlack (ins s)                       
  where ins Empty  = Noeud R Empty x Empty
        ins (Noeud color g y d)
          | x < y  = equilibrer color (ins g) y d
          | x == y = Noeud color g y d
          | x > y  = equilibrer color g y (ins d)
        makeBlack (Noeud _ g y d) = Noeud B g y d

        --Sous fonction d'équilibrage utilisée exclusievement pour l'insertion 

equilibrer :: Color -> Tree -> Int -> Tree -> Tree
equilibrer B (Noeud R (Noeud R a x b) y c) z d = Noeud R (Noeud B a x b) y (Noeud B c z d)-- 1 er cas 
equilibrer B (Noeud R a x (Noeud R b y c)) z d = Noeud R (Noeud B a x b) y (Noeud B c z d)-- 2 em cas 
equilibrer B a x (Noeud R (Noeud R b y c) z d) = Noeud R (Noeud B a x b) y (Noeud B c z d)-- 3 em cas 
equilibrer B a x (Noeud R b y (Noeud R c z d)) = Noeud R (Noeud B a x b) y (Noeud B c z d)-- 4 em cas
equilibrer color a x b = Noeud color a x b



--5
------------------------------------------Fonction qui transforme un Arbre Binaire de Recherche en AVL---------------------------
                                        --Ici on effectue un équilibrage semblable à celui de l'insertin 
                                        --mise à part qu'il y a des appel récursifs pour chaque cas.       



abrtoavl :: ABR -> ABR
abrtoavl E = E
abrtoavl (Node (Node E x E) y E )            = Node (Node E x E) y E
abrtoavl (Node E x (Node E y E) )            = Node E x (Node E y E)                   
abrtoavl (Node (Node (Node a x b) y c) z d ) = Node (Node (abrtoavl a) x (abrtoavl b)) y (Node (abrtoavl c) z (abrtoavl d))
abrtoavl (Node (Node a x (Node b y c)) z d ) = Node (Node (abrtoavl a) x (abrtoavl b)) y (Node (abrtoavl c) z (abrtoavl d))
abrtoavl (Node a x (Node (Node b y c) z d) ) = Node (Node (abrtoavl a) x (abrtoavl b)) y (Node (abrtoavl c) z (abrtoavl d))
abrtoavl (Node a x (Node b y (Node c z d)) ) = Node (Node (abrtoavl a) x (abrtoavl b)) y (Node (abrtoavl c) z (abrtoavl d))


--
--la fonction ajoute 1 à chaque élément de l'AVG
supp :: Tree -> Tree
supp Empty = Empty
supp (Noeud c ls val rs) = Noeud c (supp ls) (val+1) (supp rs)

--
-- la fonction double chaque élément de l'AVG
double :: Tree -> Tree
double Empty = Empty
double (Noeud c ls val rs) = Noeud c (double ls) (val*2) (double rs)

--
-- la fonction inverse le signe de chaque élément de l'AVG
reverseSigne :: Tree -> Tree
reverseSigne Empty = Empty
reverseSigne (Noeud c ls val rs) = Noeud c (reverseSigne rs) (-val) (reverseSigne ls)



--
-- la fonction fusionne les deux AVL donnés
fusion :: Tree -> Tree -> Tree
fusion Empty Empty = Empty
fusion Empty (Noeud c g cle d) = (Noeud c g cle d)
fusion (Noeud c g cle d) Empty = (Noeud c g cle d)
fusion (Noeud c g cle d) (Noeud c2 g2 cle2 d2) = inserer cle2 (fusion g2(fusion d2(Noeud c g cle d)))


-----------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------                                  ------------------------------------------------------
-------------------------------------------Corrections apportées à la phase 1------------------------------------------------------
-------------------------------------------                                  ------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------

-----Fonction de suppression ------
--Correction du matching non exhaustif

----Fonction de fusion incorrecte dans le cas de deux arbres non vides 


-----------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------                    --------------------------------------------------------------------
-------------------------------------------    Explications    --------------------------------------------------------------------
-------------------------------------------                    --------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------

{-
 Pour la fonction supprimer des explications s'impose :
    Pour contourner la difficulté des differents cas à traiter et compte tenu d'une foction "inserer"
    particulièrement éfficace nous avons de décidé de faire simple, 
    que fait la foction "delete" :
      1- "supprimer" prend l'arbre cherche le noeud a supprimer le supprime et équlibre le sous arbre (à partir du niveau de la suppréssion)
      2- "suppr" prend l'arbre de déparart et supprime le noeud à supprimer et tous ses fils et mets à la place un "Empty"
      3- "delete" fusionne le résultat de "supprimer" et "suppr"




-----------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------  Exemple d'utilisation  ------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------

     Fonction "inserer"

inserer 19 Empty
inserer 15 (Noeud B Empty 19 Empty)
inserer 5 (Noeud B (Noeud R Empty 15 Empty) 19 Empty)
inserer 3 (Noeud B (Noeud B Empty 5 Empty) 15 (Noeud B Empty 19 Empty))

-----------------------

    Fonction delete  "suppretion"
delete (Noeud B (Noeud B (Noeud R Empty 3 Empty) 5 Empty) 15 (Noeud B Empty 19 Empty)) 5

-----------------------

   Fonction search   "recherche"
search 3 (Noeud B (Noeud B (Noeud R Empty 3 Empty) 5 Empty) 15 (Noeud B Empty 19 Empty))

-----------------------

  Fonction supp    "incremente de 1"
supp (Noeud B (Noeud B (Noeud R Empty 3 Empty) 5 Empty) 15 (Noeud B Empty 19 Empty))

-----------------------

  Fonction double "multiplie toutes les clés de l'abre par 2 "
double (Noeud B (Noeud B (Noeud R Empty 3 Empty) 5 Empty) 15 (Noeud B Empty 19 Empty))

-----------------------
 
  Fonction "reverseSigne" inverse tous les signes de l'abre 
reverseSigne (Noeud B (Noeud B (Noeud R Empty 3 Empty) 5 Empty) 15 (Noeud B Empty 19 Empty))

-----------------------

  Fonction "fusion " fusionne deux arbre 

fusion (Noeud B (Noeud R Empty 3 Empty) 5 Empty) (Noeud B Empty 15 (Noeud B Empty 19 Empty))

-----------------------

  Fonction "abrtoavl" transforme un abr en avl 
abrtoavl (Node (Node (Node E 3 E) 5 E) 8 E)


-}
